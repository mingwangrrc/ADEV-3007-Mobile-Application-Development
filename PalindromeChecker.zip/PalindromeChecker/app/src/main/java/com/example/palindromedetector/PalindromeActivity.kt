package com.example.palindromedetector

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PalindromeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Removed advanced methods for simplicity
        setContentView(R.layout.activity_palindrome)

        // Get the Back button
        val backButton = findViewById<Button>(R.id.btnpalindromeback)
        // Set onClick listener to return to the previous activity
        backButton.setOnClickListener {
            finish() // Closes current activity and returns to previous one
        }

        // Get the TextView to display the message
        val textView = findViewById<TextView>(R.id.textViewPalindrome)
        // Receive the message passed from MainActivity
        val message = intent.getStringExtra("message")
        // Display the message
        textView.text = message
    }
}
