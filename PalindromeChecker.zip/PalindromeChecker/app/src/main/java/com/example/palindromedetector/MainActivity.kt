package com.example.palindromedetector

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Removed advanced methods for simplicity
        setContentView(R.layout.activity_main)

        val palindromeButton = findViewById<Button>(R.id.btnpalindrome)
        val pangramButton = findViewById<Button>(R.id.btnpangram)
        val editText = findViewById<EditText>(R.id.editText)

        // When click "Check for Palindrome"
        palindromeButton.setOnClickListener {
            // Create intent and send message to PalindromeActivity
            val intent = Intent(this, PalindromeActivity::class.java)
            // Pass the result message to the intent
            intent.putExtra("message", isPalindrome(editText.text.toString()))
            // Start the activity
            startActivity(intent)
        }

        // When click "Check for Pangram"
        pangramButton.setOnClickListener {
            // Create intent and send message to PangramActivity
            val intent = Intent(this, PangramActivity::class.java)
            // Pass the result message to the intent
            intent.putExtra("message", isPangram(editText.text.toString()))
            // Start the activity
            startActivity(intent)
        }
    }

    // Function to check palindrome
    fun isPalindrome(input: String): String {
        // Filter input to ignore non-alphanumeric characters and convert to lowercase
        val tempInput = input.filter { it.isLetterOrDigit() }.lowercase()
        // Check if the string is a palindrome
        return if (tempInput == tempInput.reversed()) {
            "\"$input\" is a palindrome."
        } else {
            "\"$input\" is not a palindrome, try again."
        }
    }

    // Function to check pangram
    fun isPangram(input: String): String {
        // Filter input to ignore non-letter characters and convert to lowercase
        val tempInput = input.filter { it.isLetter() }.lowercase().toSet()
        // Define the set of alphabets
        val alphabet = ('a'..'z').toSet()
        // Check if input contains all letters in the alphabet
        return if (alphabet.all { it in tempInput }) {
            "\"$input\" is a pangram."
        } else {
            "\"$input\" is not a pangram."
        }
    }
}
