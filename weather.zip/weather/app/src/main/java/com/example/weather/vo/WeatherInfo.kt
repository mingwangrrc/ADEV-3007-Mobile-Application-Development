package com.example.weather.vo

class WeatherInfo {
}