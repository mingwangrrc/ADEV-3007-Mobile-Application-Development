// Book class
data class Book(var bookName: String,
                var author: String,
                var publisher: String,
                var firstPublish: String,
                var isbn: String,
                var isAvailable: Boolean = true)

// Library class
class Library {
    private val books = mutableListOf<Book>()

    // Add book method
    fun addBook(book: Book) {
        books.add(book)
    }

    // Removes book method
    fun removeBook(title: String) {
        books.removeIf { it.bookName == title }
    }

    // Displays all available books method
    fun displayAvailableBooks() {
        books.filter { it.isAvailable }
            .forEach { println("Title: ${it.bookName}, Author: ${it.author}") }
    }

    // Borrows a book by marking it as unavailable
    fun borrowBook(title: String): Boolean {
        val book = books.find { it.bookName == title && it.isAvailable }
        return if (book != null) {
            book.isAvailable = false
            true
        } else {
            false
        }
    }

    // Returns the number of available books by a particular author
    fun getAvailableBooksCountByAuthor(author: String): Int {
        return books.count { it.author == author && it.isAvailable }
    }
}

// Main method
fun main() {
    val library = Library()

    // Adding books to the library
    library.addBook(Book("1984", "George Orwell", "", "1949", "978-0452284234"))
    library.addBook(Book("Animal Farm", "George Orwell", "", "1945","978-0-452-28424-1"))
    library.addBook(Book("The diary of a young girl", "Anne Frank", "Contact publishing", "1947",""))
    library.addBook(Book("The moon and sixpence", "William Somerset Maugham", "William Heinemann", "1919",""))
    // Displaying available books
    println("Available Books:")
    library.displayAvailableBooks()
    println()

    // Borrowing a book
    println("Borrowing '1984': ${library.borrowBook("1984")}")

    // Displaying available books after borrowing
    println("Available Books after borrowing:")
    library.displayAvailableBooks()

    // Getting the count of available books by George Orwell
    println("Available books by George Orwell: ${library.getAvailableBooksCountByAuthor("George Orwell")}")
    println()

    // Remove a book
    println("Remove book: 'The moon and sixpence'")
    library.removeBook("The moon and sixpence")
    library.displayAvailableBooks()
}
